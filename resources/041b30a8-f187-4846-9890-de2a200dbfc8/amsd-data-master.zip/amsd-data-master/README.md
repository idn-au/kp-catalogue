# amsd-data
Data repository for the <a href="https://amsd.clld.org">Australian Message Stick Database</a>.

## Citation
Kelly, Piers, Junran Lei, Hans-Jörg Bibiko, and Lorina Barker. 2024.
"AMSD: The Australian Message Stick Database."
PLOS One 19 (4): e0299712.
doi: <a href="https://doi.org/10.1371/journal.pone.0299712">https://doi.org/10.1371/journal.pone.0299712</a>
