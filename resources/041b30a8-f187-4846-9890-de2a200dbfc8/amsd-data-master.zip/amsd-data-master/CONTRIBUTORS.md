# Contributors

Name               | GitHub user     | Description                          | Role
---                | ---             | ---                                  | ---
Piers Kelly |  | author, data entry | Author
Junran Lei |  | author | Author
Hans-Jörg Bibiko | @Bibiko | patron, data maintainer | Author
Lorina Barker |  | author, data entry | Author
